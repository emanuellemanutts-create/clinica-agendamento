import mysql.connector
from datetime import datetime

# conexão com o banco
conexao = mysql.connector.connect(
    host="localhost",
    user="root",
    password="@senai508",
    database="clinica"
)

cursor = conexao.cursor()

print("Conectado com sucesso!")

# entrada de dados
nome = input("Nome do cliente: ")
telefone = input("Telefone: ")
medico = input("Médico: ")
especialidade = input("Especialidade: ")
data = input("Data (AAAA-MM-DD HH:MM): ")

data_formatada = datetime.strptime(data, "%Y-%m-%d %H:%M")

# insert no banco
sql = "INSERT INTO agendamentos (nome, telefone, medico, especialidade, data_agendamento) VALUES (%s, %s, %s, %s, %s)"
valores = (nome, telefone, medico, especialidade, data_formatada)

cursor.execute(sql, valores)
conexao.commit()

print("Agendamento realizado com sucesso!")

cursor.close()
conexao.close()