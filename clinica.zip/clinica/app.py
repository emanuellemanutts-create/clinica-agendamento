from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

def conectar():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="@senai508",
        database="clinica"
    )

medicos = {
    "Emanuelly Batista Gonzaga": "Urologista",
    "Guilherme Moraes": "Ginecologista",
    "Carlos Silva": "Cardiologista",
    "Ana Souza": "Dermatologista",
    "Pedro Lima": "Ortopedista"
}

@app.route("/", methods=["GET", "POST"])
def index():
    mensagem = ""

    if request.method == "POST":
        nome = request.form["nome"]
        telefone = request.form["telefone"]
        medico = request.form["medico"]
        especialidade = medicos[medico]
        data = request.form["data"]

        conexao = conectar()
        cursor = conexao.cursor()

        sql = """
        INSERT INTO agendamentos (nome, telefone, medico, especialidade, data_agendamento)
        VALUES (%s, %s, %s, %s, %s)
        """
        valores = (nome, telefone, medico, especialidade, data)

        cursor.execute(sql, valores)
        conexao.commit()

        cursor.close()
        conexao.close()

        mensagem = "Agendamento realizado com sucesso!"

    return render_template("index.html", medicos=medicos, mensagem=mensagem)


@app.route("/agendamentos")
def listar():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("SELECT * FROM agendamentos")
    dados = cursor.fetchall()

    cursor.close()
    conexao.close()

    return render_template("agendamentos.html", dados=dados)


# 🔥 ROTA DE EXCLUIR
@app.route("/excluir/<int:id>")
def excluir(id):
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("DELETE FROM agendamentos WHERE id = %s", (id,))
    conexao.commit()

    cursor.close()
    conexao.close()

    return redirect("/agendamentos")


if __name__ == "__main__":
    app.run(debug=True)